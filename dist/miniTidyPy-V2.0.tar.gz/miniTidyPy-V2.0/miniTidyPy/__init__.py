## initialize
name = "miniTidyPy"
from miniTidyPy.my_gather import my_gather
from miniTidyPy.my_spread import my_spread
from miniTidyPy.my_dropna import my_dropna
